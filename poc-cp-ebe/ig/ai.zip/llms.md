# ans.fr.doctrine#0.1.1: Doctrine et gouvernance du cadre d'interopérabilité des systèmes d'informations en santé (CI-SIS)

## Pages

* [Accueil](index.md)
* [Historique des versions](change-log.md)
* [Expression des besoins (EBE) et gestion des Change Proposals (CP)](ebe-cp.md)
* [Trajectoire interopérabilité](trajectoire-iop.md)
* [Cycle de vie des spécifications](cycle-de-vie.md)
* [Artifacts Summary](artifacts.md)
* [Comitologie du CI-SIS](comitologie.md)
* [Choix des normes et standard](choix-standard.md)
* [Interactions avec l'écosystème](interactions-ecosysteme.md)
* [Unité de production externe](up-externe.md)
* [Doctrine](doctrine.md)
* [Méthode d'élaboration des échanges fonctionnels](elaboration.md)

## Resources

### ImplementationGuides

* [Doctrine et gouvernance du cadre d'interopérabilité des systèmes d'informations en santé (CI-SIS)](index.md)
